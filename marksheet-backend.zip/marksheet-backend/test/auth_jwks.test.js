const { test, beforeEach } = require("node:test");
const assert = require("node:assert/strict");
const crypto = require("crypto");
const { verifyToken, resetKeyCache } = require("../src/auth");

const b64u = b => Buffer.from(b).toString("base64").replace(/=+$/, "").replace(/\+/g, "-").replace(/\//g, "_");
const now = Math.floor(Date.now() / 1000);
const ISS = "https://proj.supabase.co/auth/v1";
const URL_ = ISS + "/../.well-known/jwks.json";

const ec = crypto.generateKeyPairSync("ec", { namedCurve: "P-256" });
const rsa = crypto.generateKeyPairSync("rsa", { modulusLength: 2048 });
const ecJwk = { ...ec.publicKey.export({ format: "jwk" }), kid: "ec-1", alg: "ES256", use: "sig" };
const rsaJwk = { ...rsa.publicKey.export({ format: "jwk" }), kid: "rsa-1", alg: "RS256", use: "sig" };

function sign(alg, kid, priv, payload) {
  const h = b64u(JSON.stringify({ alg, typ: "JWT", kid })), p = b64u(JSON.stringify(payload));
  const data = Buffer.from(h + "." + p);
  const sig = alg === "ES256"
    ? crypto.sign("sha256", data, { key: priv, dsaEncoding: "ieee-p1363" })
    : crypto.sign("RSA-SHA256", data, priv);
  return `${h}.${p}.${b64u(sig)}`;
}
const good = { sub: "u1", email: "s@x.com", aud: "authenticated", iss: ISS, exp: now + 600 };
let calls = 0, keys = [ecJwk, rsaJwk];
const fetchImpl = async () => { calls++; return { ok: true, json: async () => ({ keys }) }; };
const opts = () => ({ jwksUrl: URL_, issuer: ISS, fetchImpl });
beforeEach(() => { resetKeyCache(); calls = 0; keys = [ecJwk, rsaJwk]; });

test("accepts a valid ES256 token", async () => {
  assert.deepEqual(await verifyToken(sign("ES256", "ec-1", ec.privateKey, good), opts()), { id: "u1", email: "s@x.com" });
});
test("accepts a valid RS256 token", async () => {
  assert.deepEqual(await verifyToken(sign("RS256", "rsa-1", rsa.privateKey, good), opts()), { id: "u1", email: "s@x.com" });
});
test("rejects a token signed by a different key", async () => {
  const other = crypto.generateKeyPairSync("ec", { namedCurve: "P-256" });
  assert.equal(await verifyToken(sign("ES256", "ec-1", other.privateKey, good), opts()), null);
});
test("rejects expired, wrong issuer and wrong audience", async () => {
  assert.equal(await verifyToken(sign("ES256", "ec-1", ec.privateKey, { ...good, exp: now - 5 }), opts()), null);
  assert.equal(await verifyToken(sign("ES256", "ec-1", ec.privateKey, { ...good, iss: "https://evil.example/auth/v1" }), opts()), null);
  assert.equal(await verifyToken(sign("ES256", "ec-1", ec.privateKey, { ...good, aud: "anon" }), opts()), null);
});
test("rejects an unknown key id after one refresh", async () => {
  assert.equal(await verifyToken(sign("ES256", "nope", ec.privateKey, good), opts()), null);
  assert.equal(calls, 2);                                  // first fetch + one forced refresh
});
test("picks up a rotated key", async () => {
  keys = [];
  const t = sign("ES256", "ec-1", ec.privateKey, good);
  assert.equal(await verifyToken(t, opts()), null);        // key missing
  keys = [ecJwk];
  assert.deepEqual(await verifyToken(t, opts()), { id: "u1", email: "s@x.com" });
});
test("caches keys between requests", async () => {
  const t = sign("ES256", "ec-1", ec.privateKey, good);
  await verifyToken(t, opts()); await verifyToken(t, opts());
  assert.equal(calls, 1);
});
test("blocks algorithm confusion: HS256 signed with the public key", async () => {
  const h = b64u(JSON.stringify({ alg: "HS256", typ: "JWT", kid: "ec-1" })), p = b64u(JSON.stringify(good));
  const forged = `${h}.${p}.${b64u(crypto.createHmac("sha256", JSON.stringify(ecJwk)).update(h + "." + p).digest())}`;
  assert.equal(await verifyToken(forged, opts()), null);   // no HS256 secret configured
});
test("rejects when the key type does not match the algorithm", async () => {
  keys = [{ ...rsaJwk, kid: "ec-1" }];
  assert.equal(await verifyToken(sign("ES256", "ec-1", ec.privateKey, good), opts()), null);
});
test("rejects the none algorithm and garbage", async () => {
  const h = b64u(JSON.stringify({ alg: "none" })), p = b64u(JSON.stringify(good));
  assert.equal(await verifyToken(`${h}.${p}.`, opts()), null);
  assert.equal(await verifyToken("not-a-token", opts()), null);
});
