const { test } = require("node:test");
const assert = require("node:assert/strict");
const { parseText, normalizeGrade } = require("../src/parser");

test("reads a standard semester table", () => {
  const text = [
    "Semester: 1",
    "CS3301 Data Structures 4 O",
    "MA3251 Statistics and Numerical Methods 4 A+",
    "GE3151 Problem Solving 3 A",
    "SGPA: 9.12",
    "Semester: 2",
    "CS3351 Digital Principles 4 B+",
    "SGPA: 7.80",
    "CGPA: 8.46",
  ].join("\n");
  const r = parseText(text);
  assert.equal(r.semesters.length, 2);
  assert.equal(r.semesters[0].courses.length, 3);
  assert.equal(r.semesters[0].courses[0].code, "CS3301");
  assert.equal(r.semesters[0].courses[0].credits, 4);
  assert.equal(r.semesters[0].courses[0].grade, "O");
  assert.equal(r.semesters[0].printed_sgpa, 9.12);
  assert.equal(r.semesters[1].courses[0].grade, "B+");
  assert.equal(r.printed_cgpa, 8.46);
  assert.deepEqual(r.unclear, []);
});

test("handles a split course code and a roman semester heading", () => {
  const r = parseText("Semester III\nCS 3301 Data Structures 4 A");
  assert.equal(r.semesters[0].semester, 3);
  assert.equal(r.semesters[0].courses[0].code, "CS3301");
});

test("ignores totals and header rows", () => {
  const r = parseText("Semester: 1\nTotal Credits 20 A\nCS3301 Data Structures 4 A");
  assert.equal(r.semesters[0].courses.length, 1);
});

test("flags rows it cannot read instead of guessing", () => {
  const r = parseText("Semester: 1\nSome garbled line here A");
  assert.equal(r.semesters[0] ? r.semesters[0].courses.length : 0, 0);
  assert.equal(r.unclear.length, 1);
});

test("normalises common OCR grade misreads", () => {
  assert.equal(normalizeGrade("At"), "A+");
  assert.equal(normalizeGrade("o"), "O");
  assert.equal(normalizeGrade("Z"), null);
});

test("rows without a semester heading are flagged", () => {
  const r = parseText("CS3301 Data Structures 4 A");
  assert.ok(r.unclear.some(u => u.includes("No semester heading")));
});
