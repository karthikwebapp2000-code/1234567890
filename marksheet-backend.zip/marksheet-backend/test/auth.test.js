const { test } = require("node:test");
const assert = require("node:assert/strict");
const crypto = require("crypto");
const { verifySupabaseToken } = require("../src/auth");

const SECRET = "test-secret";
const b64u = b => Buffer.from(b).toString("base64").replace(/=+$/, "").replace(/\+/g, "-").replace(/\//g, "_");
function sign(payload, secret = SECRET, alg = "HS256") {
  const h = b64u(JSON.stringify({ alg, typ: "JWT" }));
  const p = b64u(JSON.stringify(payload));
  const s = b64u(crypto.createHmac("sha256", secret).update(h + "." + p).digest());
  return `${h}.${p}.${s}`;
}
const now = Math.floor(Date.now() / 1000);

test("accepts a valid signed-in user token", () => {
  const u = verifySupabaseToken(sign({ sub: "user-1", email: "a@b.com", aud: "authenticated", exp: now + 600 }), SECRET);
  assert.deepEqual(u, { id: "user-1", email: "a@b.com" });
});
test("rejects a token signed with another secret", () => {
  assert.equal(verifySupabaseToken(sign({ sub: "x", aud: "authenticated", exp: now + 600 }, "other"), SECRET), null);
});
test("rejects an expired token", () => {
  assert.equal(verifySupabaseToken(sign({ sub: "x", aud: "authenticated", exp: now - 10 }), SECRET), null);
});
test("rejects the 'none' algorithm", () => {
  const h = b64u(JSON.stringify({ alg: "none" })), p = b64u(JSON.stringify({ sub: "x", aud: "authenticated", exp: now + 600 }));
  assert.equal(verifySupabaseToken(`${h}.${p}.`, SECRET), null);
});
test("rejects tokens for other audiences", () => {
  assert.equal(verifySupabaseToken(sign({ sub: "x", aud: "anon", exp: now + 600 }), SECRET), null);
});
test("rejects tampered payloads", () => {
  const t = sign({ sub: "x", aud: "authenticated", exp: now + 600 });
  const [h, , s] = t.split(".");
  const forged = b64u(JSON.stringify({ sub: "admin", aud: "authenticated", exp: now + 600 }));
  assert.equal(verifySupabaseToken(`${h}.${forged}.${s}`, SECRET), null);
});
