# Marksheet Backend (self-hosted OCR)

Reads marksheet images and PDFs on **your own server** with Tesseract and Poppler.
No third-party AI or OCR service is called. Uploaded files are deleted as soon as they are read.

## What runs where

| Part | Where it can run | Notes |
|---|---|---|
| Frontend (`marksheet-frontend/index.html`) | Netlify, Vercel, GitHub Pages, Supabase Storage | Static files only. |
| Backend (`marksheet-backend/`) | Docker host: Render, Railway, Fly.io, a VPS, or your own PC | Needs the Tesseract and Poppler programs installed. |
| Database and login | Supabase | The backend only checks the login token. It stores nothing. |
| Android and iOS apps | Capacitor wrapper around the frontend, or the same API | Same `API_BASE`. |

**Vercel, Netlify and Supabase Edge Functions cannot run the Tesseract program**, so the OCR part needs a Docker host. Netlify and Vercel can host the frontend.

## Run it on your computer first

```bash
# Requires: Node 18+, tesseract-ocr (with English data), poppler-utils
cd marksheet-backend
npm install
cp .env.example .env        # then fill in SUPABASE_JWT_SECRET or MARKSHEET_API_KEY
export $(grep -v '^#' .env | xargs)
npm start
```

Test it:

```bash
curl -X POST -H "x-api-key: $MARKSHEET_API_KEY" -F "file=@marksheet.jpg" http://localhost:8080/api/read-marksheet
```

## Docker

```bash
docker build -t marksheet-api .
docker run -p 8080:8080 --env-file .env marksheet-api
```

Deploy the same image to Render, Railway or Fly.io, and set the environment variables there.
Always serve it over HTTPS.

## Tests

```bash
npm test
```

## Security checklist

- [ ] HTTPS only.
- [ ] `SUPABASE_JWT_SECRET` set, so only signed-in users can call the API.
- [ ] `ALLOWED_ORIGINS` lists only your own sites.
- [ ] `.env` is in `.gitignore` and never committed to GitHub.
- [ ] The API key is used only by your own server scripts, never in the frontend or the apps.
- [ ] Your privacy policy says uploads are processed by your server and deleted after reading.
- [ ] Server logs record errors only, not file contents (the code does this).

## Accuracy

OCR accuracy depends on the photo. Clear, flat, well-lit scans read best. The parser flags any row it cannot read, and the frontend shows every row for checking before a result is calculated. Always compare the final result with the original marksheet.
