// Turns raw OCR text into structured rows. Pure function, no I/O, so it is easy to test.
// Anything it cannot read with confidence goes into "unclear" instead of being guessed.

const GRADES = new Set(["O", "A+", "A", "B+", "B", "C", "D", "P", "U", "RA", "W", "AB", "F"]);
const SKIP = /\b(total|result|grand|total\s+credits|credits\s+earned|remarks|name\s+of|register|subject\s+code|course\s+code|sl\.?\s*no)\b/i;

function normalizeLine(line) {
  return line.replace(/[|]/g, " ").replace(/\s+/g, " ").trim();
}

// OCR often reads "A+" as "A+", "At" or "A +". Map the common cases back.
function normalizeGrade(tok) {
  const t = tok.toUpperCase().replace(/[.,;:]$/, "");
  if (GRADES.has(t)) return t;
  if (t === "AT" || t === "A+" ) return "A+";
  if (t === "0" ) return "O";
  return null;
}

function parseSemesterHeader(line) {
  const m = line.match(/\bsem(?:ester)?\s*[:\-]?\s*(\d{1,2}|[IVX]{1,4})\b/i);
  if (!m) return null;
  const roman = { I: 1, II: 2, III: 3, IV: 4, V: 5, VI: 6, VII: 7, VIII: 8, IX: 9, X: 10 };
  const v = m[1];
  return /^\d+$/.test(v) ? Number(v) : (roman[v.toUpperCase()] || null);
}

// Course code like CS3301, GE 6151, MA3251 (2 to 4 letters, 3 to 4 digits, optional suffix)
function matchCode(tokens, i) {
  const t = tokens[i];
  if (/^[A-Z]{2,4}\d{3,4}[A-Z]?$/i.test(t)) return { code: t.toUpperCase(), used: 1 };
  if (/^[A-Z]{2,4}$/i.test(t) && tokens[i + 1] && /^\d{3,4}[A-Z]?$/i.test(tokens[i + 1])) {
    return { code: (t + tokens[i + 1]).toUpperCase(), used: 2 };
  }
  return null;
}

function parseText(text) {
  const result = { student_name: null, printed_cgpa: null, semesters: [], unclear: [] };
  let current = null;
  let sawSemester = false;

  const ensureSemester = (n) => {
    let sem = result.semesters.find(s => s.semester === n);
    if (!sem) { sem = { semester: n, printed_sgpa: null, courses: [] }; result.semesters.push(sem); }
    return sem;
  };

  const lines = text.split(/\r?\n|\f/).map(normalizeLine).filter(Boolean);

  for (const line of lines) {
    const sem = parseSemesterHeader(line);
    if (sem !== null) { current = ensureSemester(sem); sawSemester = true; }

    const cg = line.match(/\bCGPA\b\D{0,12}(\d{1,2}\.\d{1,3})/i);
    if (cg) result.printed_cgpa = Number(cg[1]);

    const sg = line.match(/\bSGPA\b\D{0,12}(\d{1,2}\.\d{1,3})/i);
    if (sg && current) current.printed_sgpa = Number(sg[1]);

    const nm = line.match(/\bname\s*[:\-]\s*([A-Za-z .]{3,})/i);
    if (nm && !result.student_name) result.student_name = nm[1].trim();

    if (sem !== null || cg || sg || nm) continue;          // header-type lines
    if (SKIP.test(line)) continue;

    const tokens = line.split(" ");
    // Find the grade: the last token that is a valid grade
    let gi = -1, grade = null;
    for (let i = tokens.length - 1; i >= 0; i--) {
      const g = normalizeGrade(tokens[i]);
      if (g) { gi = i; grade = g; break; }
    }
    if (gi < 0) continue;                                   // not a course row at all

    // Credits: the number directly before the grade
    const credits = gi > 0 ? Number(tokens[gi - 1]) : NaN;
    const creditsOk = Number.isFinite(credits) && credits > 0 && credits <= 10;

    // Course code: first token(s) that look like a code
    let code = null, codeEnd = 0;
    for (let i = 0; i < Math.min(3, gi); i++) {
      const m = matchCode(tokens, i);
      if (m) { code = m.code; codeEnd = i + m.used; break; }
    }
    const nameTokens = tokens.slice(codeEnd, creditsOk ? gi - 1 : gi);
    const name = nameTokens.join(" ").trim() || null;

    if (!creditsOk || !code) {
      result.unclear.push(`Could not read a complete row: "${line}"`);
      continue;
    }

    const target = current || ensureSemester(1);
    target.courses.push({ code, name, credits, grade, source_line: line });
  }

  if (!sawSemester && result.semesters.length) {
    result.unclear.push("No semester heading found. All rows were put under semester 1, so check them.");
  }
  result.semesters = result.semesters.filter(s => s.courses.length || s.printed_sgpa !== null);
  return result;
}

module.exports = { parseText, normalizeGrade, GRADES };
