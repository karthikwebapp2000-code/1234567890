// Verifies a Supabase access token on your own server.
//  - HS256: checked locally with your project's legacy JWT secret (no network call).
//  - ES256 / RS256: checked with your project's public keys (JWKS), fetched from YOUR Supabase project
//    and cached for 10 minutes. Newer Supabase projects sign tokens this way by default.
const crypto = require("crypto");

const b64urlDecode = (str) => Buffer.from(String(str).replace(/-/g, "+").replace(/_/g, "/"), "base64");

function decodeParts(token) {
  const parts = String(token || "").split(".");
  if (parts.length !== 3) return null;
  try {
    return {
      h: parts[0], p: parts[1], sig: b64urlDecode(parts[2]),
      header: JSON.parse(b64urlDecode(parts[0]).toString("utf8")),
      payload: JSON.parse(b64urlDecode(parts[1]).toString("utf8")),
    };
  } catch { return null; }
}

function claimsOk(payload, issuer) {
  const now = Math.floor(Date.now() / 1000);
  if (!payload.exp || payload.exp < now) return false;           // expired or no expiry
  if (payload.aud !== "authenticated") return false;             // signed-in user tokens only
  if (issuer && payload.iss !== issuer) return false;            // must come from YOUR project
  return true;
}

// Legacy HS256 (kept synchronous: used by the unit tests and by verifyToken below).
function verifySupabaseToken(token, secret) {
  const t = decodeParts(token);
  if (!t || t.header.alg !== "HS256" || !secret) return null;    // refuses "none" and other algorithms
  const expected = crypto.createHmac("sha256", secret).update(t.h + "." + t.p).digest();
  if (t.sig.length !== expected.length || !crypto.timingSafeEqual(t.sig, expected)) return null;
  if (!claimsOk(t.payload)) return null;
  return { id: t.payload.sub, email: t.payload.email || null };
}

// JWKS cache
let cache = { url: null, keys: null, at: 0 };
async function getKeys(jwksUrl, fetchImpl, force) {
  const fresh = cache.url === jwksUrl && cache.keys && Date.now() - cache.at < 10 * 60 * 1000;
  if (fresh && !force) return cache.keys;
  const res = await fetchImpl(jwksUrl);
  if (!res.ok) throw new Error("JWKS fetch failed: " + res.status);
  const body = await res.json();
  cache = { url: jwksUrl, keys: Array.isArray(body.keys) ? body.keys : [], at: Date.now() };
  return cache.keys;
}
function resetKeyCache() { cache = { url: null, keys: null, at: 0 }; }

async function verifyAsymmetric(t, { jwksUrl, issuer, fetchImpl }) {
  const alg = t.header.alg;
  if (alg !== "ES256" && alg !== "RS256") return null;
  if (!jwksUrl || !t.header.kid) return null;
  let keys = await getKeys(jwksUrl, fetchImpl, false);
  let jwk = keys.find(k => k.kid === t.header.kid);
  if (!jwk) { keys = await getKeys(jwksUrl, fetchImpl, true); jwk = keys.find(k => k.kid === t.header.kid); }   // key rotation
  if (!jwk) return null;
  const expectedKty = alg === "ES256" ? "EC" : "RSA";
  if (jwk.kty !== expectedKty) return null;                      // stops algorithm confusion
  const key = crypto.createPublicKey({ key: jwk, format: "jwk" });
  const data = Buffer.from(t.h + "." + t.p);
  const ok = alg === "ES256"
    ? crypto.verify("sha256", data, { key, dsaEncoding: "ieee-p1363" }, t.sig)
    : crypto.verify("RSA-SHA256", data, key, t.sig);
  if (!ok || !claimsOk(t.payload, issuer)) return null;
  return { id: t.payload.sub, email: t.payload.email || null };
}

// Main entry point used by the server.
async function verifyToken(token, opts = {}) {
  const t = decodeParts(token);
  if (!t) return null;
  const fetchImpl = opts.fetchImpl || fetch;
  try {
    if (t.header.alg === "HS256") return verifySupabaseToken(token, opts.secret);
    return await verifyAsymmetric(t, { jwksUrl: opts.jwksUrl, issuer: opts.issuer, fetchImpl });
  } catch { return null; }
}

module.exports = { verifySupabaseToken, verifyToken, resetKeyCache };
