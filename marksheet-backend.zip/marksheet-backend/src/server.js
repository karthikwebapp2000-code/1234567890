// Self-hosted marksheet API. Your server, your rules. No data leaves this machine
// except the response to the browser that called it.
const express = require("express");
const helmet = require("helmet");
const cors = require("cors");
const rateLimit = require("express-rate-limit");
const multer = require("multer");
const fs = require("fs/promises");
const os = require("os");
const path = require("path");
const { sniffType } = require("./validate");
const { verifyToken } = require("./auth");
const { extractText } = require("./ocr");
const { parseText } = require("./parser");

const PORT = Number(process.env.PORT || 8080);
const API_KEY = process.env.MARKSHEET_API_KEY || "";           // required in production
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || "").split(",").map(s => s.trim()).filter(Boolean);
const MAX_BYTES = Number(process.env.MAX_UPLOAD_BYTES || 10 * 1024 * 1024);
const MAX_PAGES = Number(process.env.MAX_PDF_PAGES || 6);

const app = express();
app.disable("x-powered-by");
app.use(helmet());
app.use(cors({
  origin(origin, cb) {
    // Native apps (Capacitor, etc.) send no Origin. Browsers must match the allowlist.
    if (!origin || ALLOWED_ORIGINS.includes(origin)) return cb(null, true);
    return cb(new Error("Origin not allowed"));
  }
}));

app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 60, standardHeaders: true, legacyHeaders: false }));

// Temporary upload folder. Files are deleted after each request.
const upload = multer({
  dest: path.join(os.tmpdir(), "marksheet-uploads"),
  limits: { fileSize: MAX_BYTES, files: 1 }
});

// Allowed: a signed-in Supabase user (for browsers and phone apps), or your API key (for your own server scripts).
// Never put the API key in a public web page or app: anyone can read it there.
const SUPABASE_URL = (process.env.SUPABASE_URL || "").replace(/\/+$/, "");
const JWT_OPTS = {
  secret: process.env.SUPABASE_JWT_SECRET || "",
  jwksUrl: SUPABASE_URL ? SUPABASE_URL + "/auth/v1/.well-known/jwks.json" : "",
  issuer: SUPABASE_URL ? SUPABASE_URL + "/auth/v1" : ""
};
async function requireAuth(req, res, next) {
  const auth = req.get("authorization") || "";
  if (auth.startsWith("Bearer ") && (JWT_OPTS.secret || JWT_OPTS.jwksUrl)) {
    const user = await verifyToken(auth.slice(7), JWT_OPTS);
    if (user) { req.user = user; return next(); }
    return res.status(401).json({ error: "Sign in again." });
  }
  const sent = req.get("x-api-key") || "";
  if (API_KEY && sent.length === API_KEY.length && sent === API_KEY) return next();
  return res.status(401).json({ error: "Unauthorised." });
}

app.get("/health", (req, res) => res.json({ ok: true }));

app.post("/api/read-marksheet", requireAuth, upload.single("file"), async (req, res) => {
  const file = req.file;
  if (!file) return res.status(400).json({ error: "Send one file in the 'file' field." });
  try {
    const head = Buffer.alloc(16);
    const fh = await fs.open(file.path, "r");
    await fh.read(head, 0, 16, 0);
    await fh.close();
    const type = sniffType(head);
    if (!type) return res.status(415).json({ error: "Use a PNG, JPG, WebP or PDF file." });

    const { text, pageCount } = await extractText(file.path, type, MAX_PAGES);
    const parsed = parseText(text);
    const rows = parsed.semesters.reduce((n, s) => n + s.courses.length, 0);
    return res.json({
      ...parsed,
      meta: { pages_read: pageCount, rows_found: rows, engine: "tesseract-local" }
    });
  } catch (err) {
    console.error("read-marksheet failed:", err.message);          // log the error, never the file content
    return res.status(500).json({ error: "Could not read this file. Try a sharper image with the whole table visible." });
  } finally {
    await fs.rm(file.path, { force: true }).catch(() => {});
  }
});

app.use((err, req, res, next) => {
  if (err && err.code === "LIMIT_FILE_SIZE") return res.status(413).json({ error: "File is too large (max 10 MB)." });
  if (err && err.message === "Origin not allowed") return res.status(403).json({ error: "Origin not allowed." });
  return res.status(500).json({ error: "Server error." });
});

if (require.main === module) {
  if (!API_KEY && !JWT_OPTS.secret && !JWT_OPTS.jwksUrl) console.warn("WARNING: no auth configured. Set SUPABASE_URL (new projects) or SUPABASE_JWT_SECRET (legacy), or MARKSHEET_API_KEY. All requests will be refused.");
  app.listen(PORT, () => console.log(`Marksheet API on port ${PORT}`));
}
module.exports = app;
