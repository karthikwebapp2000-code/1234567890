// Runs the local Tesseract and Poppler binaries. No network calls.
const { execFile } = require("child_process");
const fs = require("fs/promises");
const os = require("os");
const path = require("path");

const TIMEOUT_MS = Number(process.env.OCR_TIMEOUT_MS || 60000);
const LANG = process.env.OCR_LANG || "eng";

function run(cmd, args) {
  return new Promise((resolve, reject) => {
    execFile(cmd, args, { timeout: TIMEOUT_MS, maxBuffer: 20 * 1024 * 1024 }, (err, stdout, stderr) => {
      if (err) return reject(new Error(`${cmd} failed: ${stderr || err.message}`));
      resolve(stdout);
    });
  });
}

// Convert an uploaded PDF into PNG page images (300 dpi). Returns file paths.
async function pdfToPngs(pdfPath, workDir, maxPages) {
  const prefix = path.join(workDir, "page");
  await run("pdftoppm", ["-png", "-r", "300", "-l", String(maxPages), pdfPath, prefix]);
  const files = (await fs.readdir(workDir)).filter(f => f.startsWith("page") && f.endsWith(".png")).sort();
  return files.map(f => path.join(workDir, f));
}

// OCR one image. --psm 6 = assume a uniform block of text, suits marksheet tables.
async function ocrImage(imagePath) {
  return run("tesseract", [imagePath, "stdout", "-l", LANG, "--psm", "6"]);
}

// Full pipeline for one upload. Always deletes its temp files.
async function extractText(inputPath, mime, maxPages) {
  const workDir = await fs.mkdtemp(path.join(os.tmpdir(), "marks-"));
  try {
    let images;
    if (mime === "application/pdf") {
      images = await pdfToPngs(inputPath, workDir, maxPages);
    } else {
      images = [inputPath];
    }
    const pages = [];
    for (const img of images) pages.push(await ocrImage(img));
    return { text: pages.join("\n\f\n"), pageCount: images.length };
  } finally {
    await fs.rm(workDir, { recursive: true, force: true });
  }
}

module.exports = { extractText };
