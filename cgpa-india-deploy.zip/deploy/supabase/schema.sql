-- CGPA India: saved semester history
-- Run this once in the Supabase dashboard: SQL Editor > New query > paste > Run.

create table if not exists public.semester_records (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null default auth.uid() references auth.users (id) on delete cascade,
  semester_no smallint not null check (semester_no between 1 and 12),
  label       text check (label is null or char_length(label) <= 40),   -- e.g. "2024-25"
  scale       text not null check (char_length(scale) <= 80),            -- grade scale used when saved
  courses     jsonb not null default '[]'::jsonb
              check (jsonb_typeof(courses) = 'array' and jsonb_array_length(courses) <= 40),
  sgpa        numeric(4, 2),
  credits     numeric(6, 2) not null check (credits >= 0),
  points      numeric(9, 2) not null check (points >= 0),                -- sum of credits x grade points
  updated_at  timestamptz not null default now(),
  unique (user_id, semester_no)                                          -- one record per semester per student
);

create index if not exists semester_records_user_idx
  on public.semester_records (user_id, semester_no);

-- Row level security: a signed-in student can only see and change their own rows.
alter table public.semester_records enable row level security;

drop policy if exists "Students read own records"   on public.semester_records;
drop policy if exists "Students insert own records" on public.semester_records;
drop policy if exists "Students update own records" on public.semester_records;
drop policy if exists "Students delete own records" on public.semester_records;

create policy "Students read own records"
  on public.semester_records for select to authenticated
  using ((select auth.uid()) = user_id);

create policy "Students insert own records"
  on public.semester_records for insert to authenticated
  with check ((select auth.uid()) = user_id);

create policy "Students update own records"
  on public.semester_records for update to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

create policy "Students delete own records"
  on public.semester_records for delete to authenticated
  using ((select auth.uid()) = user_id);

-- Visitors who are not signed in get no access at all.
revoke all on public.semester_records from anon;
grant select, insert, update, delete on public.semester_records to authenticated;
