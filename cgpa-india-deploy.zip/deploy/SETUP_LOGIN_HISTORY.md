# Connect login, saved history and the marksheet reader

The site works without any of this: calculators run in the browser, and **guest history** is saved on the visitor's own device.
Follow these steps to add **sign-in with an account** and **history that follows the student across devices**.

Nothing here can be done from the claude.ai preview. Login and cloud history need your own hosted copy of the site (Netlify, Vercel or GitHub Pages) because a preview page is not allowed to talk to other servers.

---

## 1. Create the Supabase project (free tier is enough to start)

1. Create a project at supabase.com. Note the **Project URL** and the **anon / publishable key** (Project Settings > API).
   The anon key is meant to be public, so it is safe in the web page. What protects the data is row level security in step 2.
   Never put the `service_role` key in the website.
2. Open **SQL Editor**, paste the whole of `supabase/schema.sql`, and run it.
   This creates the `semester_records` table. Each student can only read and change their own rows.

## 2. Turn on the sign-in providers

Supabase dashboard > **Authentication > Sign In / Providers**. For every provider, copy the **callback URL** Supabase shows you
(`https://<project-ref>.supabase.co/auth/v1/callback`) into the provider's console as the redirect URI.

| Button | What you need | Notes |
|---|---|---|
| **Google** | A Google Cloud project with an OAuth client ID of type "Web application" | Free. Add your site and the Supabase callback URL to the client. |
| **Apple** | A paid **Apple Developer Program** membership (about US$99 a year), a Services ID with "Sign in with Apple", and a key | Apple's client secret is a token that **expires at least every 6 months**. Put a reminder in your calendar to regenerate it, or sign-in will stop working. |
| **Microsoft** (shown as "Azure" in Supabase) | An app registration in Microsoft Entra ID with a client secret | Make sure the `email` scope is allowed. |
| **GitHub** | An OAuth App under GitHub > Settings > Developer settings | Free. |
| **Email link** | Nothing extra to start | Supabase's built-in email sender is for testing only and is heavily rate limited. Add your own SMTP provider before launch (Authentication > SMTP Settings). |

You do not have to enable all of them. Only the providers listed in `PROVIDERS` (step 4) show a button, and a button for a provider
you have not enabled in Supabase will show an error when pressed.

Then set **Authentication > URL Configuration**:
- **Site URL**: your site's address, e.g. `https://cgpa-india.netlify.app`
- **Redirect URLs**: the same address, plus `http://localhost:5173` if you test locally.

## 3. Host the site

Put `india_cgpa_calculator.html` (rename it `index.html`), `manifest.json` and the `icons/` folder in a GitHub repository, then connect it to Netlify or Vercel.
It is a single static file, so no build command is needed.

## 4. Fill in the settings block

Open the file and search for `YOUR SETTINGS` (the block that defines `window.APP_CONFIG`, just above the page's scripts):

```js
window.APP_CONFIG = {
  SUPABASE_URL: "https://abcd1234.supabase.co",
  SUPABASE_ANON_KEY: "your anon / publishable key",
  API_BASE: "https://marksheet.yourdomain.com",     // step 5. Leave empty to keep manual entry only.
  PROVIDERS: ["google", "apple", "azure", "github"] // remove the ones you did not set up
};
```

Commit and push. Netlify or Vercel redeploys automatically.

Also upload `robots.txt` and `sitemap.xml` next to the page after replacing `YOUR-DOMAIN` in both, and add `<link rel="canonical" href="https://YOUR-DOMAIN/">` to the page head.

## 5. (Optional) Turn on the marksheet reader

The reader runs on your own server with Tesseract OCR. No AI service is involved.

1. Deploy `marksheet-backend/` as a Docker service (Render, Railway, Fly.io, or your own machine). See its `README.md`.
2. Set these environment variables on the service:
   - `SUPABASE_URL` = your project URL. The server uses it to check that each login token is real.
   - `ALLOWED_ORIGINS` = your site's address, exactly, e.g. `https://cgpa-india.netlify.app`
3. Put the service's HTTPS address in `API_BASE` (step 4).

Only signed-in students can use the reader. Without `API_BASE`, the page tells the visitor to enter grades by hand.

## 6. Test it

- [ ] Open the site, go to **Sign in**, and sign in with each provider you enabled.
- [ ] Add courses, press **Save**, open **My semesters**, and confirm the semester appears.
- [ ] Sign in on a second device or browser and confirm the same history appears.
- [ ] In Supabase > Table Editor, confirm rows have your `user_id` and that a second test account cannot see them.
- [ ] Upload a clear marksheet photo in **Marksheet** and check every extracted row before calculating.

## Things to know

- **Email links** must be opened in the same browser where you asked for them. This is a security feature of the sign-in flow.
- **Deleting an account**: deleting a user in Supabase also deletes their history (the table is set to cascade).
- **Privacy policy**: once login and history are on, your Privacy Policy must describe what you store, where, and for how long. The text on the site is a template. Have a lawyer review it.
- **Android and iPhone apps**: Google does not allow sign-in inside an app's embedded browser, so a wrapped app needs the system browser or a native sign-in plugin. Apple's App Store rules also require "Sign in with Apple" whenever an iOS app offers other social logins. Plan for both before building the apps.
